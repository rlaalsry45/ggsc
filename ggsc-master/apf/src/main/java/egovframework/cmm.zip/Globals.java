package egovframework.cmm;

public class Globals {
	public static final String boardFileUrl = "files/board/";
	
	//public static final String boardTmpFileUrl = "files/tmp/board/";
	public static final String boardTmpFileUrl = "D:/project/kga_2/eGovFrameDev-3.2.0-64bit/workspace/apf/src/main/webapp/files/board/";
	
	public static final String boardConsultUrl = "files/consult/";
	public static final String editorUploadPath = "files/editor/";
	public static final String bannerUploadPath = "files/banner/";
	public static final String popupUploadPath = "files/popup/";
	public static final String excellentUploadPath = "files/excellent/";
}
